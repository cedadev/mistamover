# BSD Licence
# Copyright (c) 2012, Science & Technology Facilities Council (STFC)
# All rights reserved.
#
# See the LICENSE file in the source distribution of this software for
# the full license text.

#from Config import Config
from BaseConfig import BaseConfig
from DatasetConfig import DatasetConfig
from GlobalConfig import GlobalConfig
