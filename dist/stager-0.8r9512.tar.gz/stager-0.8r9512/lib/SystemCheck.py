# BSD Licence
# Copyright (c) 2012, Science & Technology Facilities Council (STFC)
# All rights reserved.
#
# See the LICENSE file in the source distribution of this software for
# the full license text.

# FIXME:  implement this

class SystemCheck(object):
    def checkOutboundMailWorking(self): pass
    def checkLoggersWorking(self): pass
