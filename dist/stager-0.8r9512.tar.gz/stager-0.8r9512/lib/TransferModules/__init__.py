# BSD Licence
# Copyright (c) 2012, Science & Technology Facilities Council (STFC)
# All rights reserved.
#
# See the LICENSE file in the source distribution of this software for
# the full license text.

from TransferBase import TransferBase
from RsyncTransfer import RsyncTransfer
from GridFTPTransfer import GridFTPTransfer
